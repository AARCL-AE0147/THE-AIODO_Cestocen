import AIODO93

repone=AIODO93.AWKFaction.return_encode

def DATA200(DATA):
    if DATA["DATA"]==404:return 404
    else:
        print("返回文件--")
        AI=repone.RD200(DATA)
        return AI

def R200(DATA):
    b=repone.R200(DATA)
    
    return b

def WEB302(DATA):
    PANDA=repone.R302(DATA)
    return PANDA

def Setcookie_200(DATA):
    AODO=repone.R200_SETCOOKIE(DATA)
    return AODO

def Setcookie_new(DATA):
    AODO=repone.NEW_COOKIE(DATA)
    return AODO

def DELcookie(DATA):
    print(DATA)
    AODO=repone.del_COOKIE(DATA)
    return AODO

def STATEP(DATA):
    try:
        print(DATA["web"])
    except Exception:
        print("DATA不存在返回头")
    try:
        if DATA==404:
            return 404
    except Exception:
        pass
    
    if DATA["web"]==200:
        return R200(DATA)

    if DATA["web"]=="DATA200":
        return DATA200(DATA)
    
    if DATA["web"]=="302":
        print("重定向:",DATA["goto"])
        return WEB302(DATA)

    if DATA["web"]=="S200":
        print("在加载页面时设置COOKIE")
        return Setcookie_200(DATA)
    
    if DATA["web"]=="news200":
        print("获取cookie")
        return Setcookie_new(DATA)
    
    if DATA["web"]=="delc":
        print("删除Cookie")
        return DELcookie(DATA)
