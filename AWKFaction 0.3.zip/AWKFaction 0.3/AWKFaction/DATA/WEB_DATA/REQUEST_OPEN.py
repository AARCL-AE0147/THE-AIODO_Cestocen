def request_of_decode(DATA):
    
    return DATA.decode()

def request_of_length(DATA):

    if len(DATA)==0:return False

def request_open(SUB1,SUB2,webecho):

    if request_of_length(webecho)==False:return "size is 0"

    return request_of_decode(webecho)

