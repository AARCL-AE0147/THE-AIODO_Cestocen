import AIODO93

retuper=AIODO93.AWKFaction.return_request
HTML_load=AIODO93.AWKFaction.HTML

#下面请写你的代码