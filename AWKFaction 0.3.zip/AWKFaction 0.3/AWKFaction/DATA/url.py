import APP_index.admin
import APP_index.test

import AIODO93
import ADESK93


def urlindex(DATA):


















    ALLDEBUG=False
    DEBUG=True

    #General links 普通链接
    URLss={
        "/admin":APP_index.admin.admin_return2,
        "/admin2":APP_index.admin.admin_return3,
        "/setcookie":APP_index.admin.setcookie,
        "/CESsetcookie":APP_index.admin.setcookie_of_new,
        "/delcookie":APP_index.admin.cookie_del,
    }

    #Multiple links 多层链接
    SUPER_URL=[
        "/testing",
        "/encode",
    ]





















































    NEW_URL=DATA["url"]

    for i in SUPER_URL:
        if len(NEW_URL.replace(i,""))!=NEW_URL:
            NEW_URL=NEW_URL.replace(i,"")
            



    for i in URLss:
        
        OA=NEW_URL
        PAAA=OA.replace(".html","")                
        if PAAA==i:
            if DEBUG==True:print(f"{DATA['Host']}:{DATA['request']}->{URLss[i].__name__} For:{DATA['url']} requesthod:",end="")
            STATUS=URLss[i](DATA)
    
            return STATUS
        else:
            pass
    if DEBUG==True:print(f"{DATA['Host']}:{DATA['request']}->APP_index.admin.the404")
    return APP_index.admin.the404(DATA)






    