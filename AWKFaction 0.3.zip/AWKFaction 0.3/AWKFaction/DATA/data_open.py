import AIODO93

def request_split(DATA):
    return AIODO93.AWKFaction.web_request.request_split(DATA)

def HTML_IO(DATA):
    return AIODO93.AWKFaction.web_request.url_of_HTML(DATA,"ARELUSS_TO_FILE_IS")

def handers_IO_key(DATA):
    return AIODO93.AWKFaction.web_request.del_url_of_HTML(DATA,"ARELUSS_TO_FILE_IS")

def file_to(DATA):
    try:
        PD=DATA["ARELUSS_TO_FILE_IS"]
        print(f"{DATA['Host']}->{DATA['request']}-->{DATA['url']}")
        SOA="None"
        SO=DATA["url"].split("/")

        if len(SO[-1].replace(".mp4",""))!=len(SO[-1]):
            SOA="mp4"
            print("@->MP4")

        PER=AIODO93.AWKFaction.DATA(path=DATA["url"])
        
        PER=AIODO93.AWKFaction.return_request.return200OFDATA(PER,TYPES=SOA)

        return PER
    except Exception:
        return DATA