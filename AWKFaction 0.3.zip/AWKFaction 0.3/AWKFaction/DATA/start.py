#coding:utf-8

import socket

import AIODO93

import threading

import sys

import time



DEBUG=False

port=None

try:
    port=int(sys.argv[1])
except Exception:
    port=None

if port==None:port=9200

WEB=AIODO93.SOCKET_WEB.web_bulid(port)

print(f"""
    THE AWKFation new is START TO 127.0.0.1:{port}
    Copyright 2020 AIODO93
    NO License
    Author:ARELUSS
""")
if __name__ == '__main__':
    def tcp_open(OPEN1,OPEN2):
        try:



            

            DEBUG=False

            USERDEBUG=True

            if USERDEBUG==True:
                try:
                    AP=time.time()

                    import WEB_DATA.WEBSS as WDS

                    webecho=OPEN1.recv(WDS.OPEN())

                    import WEB_DATA.REQUEST_OPEN as WDR

                    webecho2=WDR.request_open(OPEN1,OPEN2,webecho)

                    if DEBUG==True:print(webecho2,"URL")

                    if webecho2=="size is 0":OPEN1.close()

                    import index

                    END_DATA=index.to_admin(webecho2)
                    
                    if DEBUG==True:print(END_DATA,"IS?")

                    import WEB_DATA.RETUPER as WR
                    AROS=WR.STATEP(END_DATA)
                    if AROS==404:
                        import WEB_DATA.WEB404 as W404
                        PPAI=W404.THE404()
                        OPEN1.send(PPAI)
                        print("HTTP/1.1 404 Not Found\n")
                        OPEN1.close()

                    else:
                        ac=time.time()
                        pp=ac-AP
                        f=open("./WEB_DATA/accept_time.AWKFactionMOD","a")
                        f.write(str(pp)+"\n")
                        OPEN1.send(AROS)
                        print("HTTP/1.1 200 OK\n")
                        OPEN1.close()
                except Exception as O:
                    print("致命错误",O)
                    import WEB_DATA.WEB404 as W404
                    PPAI=W404.THE404()
                    OPEN1.send(PPAI)
                    print("HTTP/1.1 404 Not Found\n")
                    OPEN1.close()
 
        except Exception:
            pass


































    while True:

        OPEN1,OPEN2=WEB.accept()

        if DEBUG==True:print("accept open")

        state=threading.Thread(target=tcp_open(OPEN1,OPEN2))

        state.start()

