import os

import sys

import shutil

OP=sys.argv

def state():

    def start1():
        if len(OP)>4:
            print("THE Command error")
        else:
            try:
                os.listdir(OP[2])
            except Exception:
                print("path ERROR")
                IA=1

            try:
                if IA==1:pass
            except Exception:
                if OP[2][-1]!="/":
                    OP[2]=OP[2]+"/"

                end=OP[2]
                OA=OP[3]
                END=end+"AWKFaction-"+OA

                os.mkdir(END)

                print("IS OK!")
    def state2():
        END=OP[2]
        END2=OP[3]
        if END2[-1]=="/":
            SOPER=END+"AWKFaction-"+END2+"DATA"
        else:SOPER=END+"AWKFaction-"+END2+"/"+"DATA"
        print(SOPER)
        shutil.copytree("DATA",SOPER)

        # SOPER=END+"AWKFaction-"+END2+"/"+"AIODO93.py"
        # print(SOPER)
        # shutil.copyfile("DATA/AIODO93.py",SOPER)

    start1()
    state2()

def help():
    if len(OP)>2:
        print("Command error")
    else:
        print("""
        AWKFaction-0.1

        state [path] [data_name]    -Creating a project

        help  [None]    -help
        """)

PP=1

try:

    if OP[1]=="start":PP=PP+1;state()

    if OP[1]=="help":PP=PP+1;help()

except Exception as O:
    print("is Command error",O)

if PP==1:
    print("TO Command error")
