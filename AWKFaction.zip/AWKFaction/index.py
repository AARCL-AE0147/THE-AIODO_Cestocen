import data_open

import url

def to_admin(DATA):
    







    GOTO=[
        data_open.request_split,
        data_open.handers_IO_key,
        data_open.HTML_IO,
        url.urlindex, 
        data_open.file_to,              
        
    ]
































    A=DATA
    for i in GOTO:
        A=i(A)
    return A