import shutil

import os

import sys

APP=sys.argv

if APP[1]=="appstart":
    
    def appstart(path):
        shutil.copyfile("WEB_DATA/RE.py",path)
    appstart(APP[2])

if APP[1]=="runserver":
    try:
        if APP[2]==None:
            the="start.py"
        else:
            the="start.py "+APP[2]
    except Exception:
        the="start.py"

    def runserver(port):
        os.system(port)

    
    runserver(the)

if APP[1]=="help":
    print("""

        runserver [port] -运行服务

        appstart [path] -创建APP
 

    """)