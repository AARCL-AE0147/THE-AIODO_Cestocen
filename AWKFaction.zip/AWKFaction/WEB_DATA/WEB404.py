import AIODO93

def THE404():
    APPIA=AIODO93.AWKFaction.ENDOF404("./HTML/404.html")
    return APPIA