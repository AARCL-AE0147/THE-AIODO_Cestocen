import APP_index.admin

def urlindex(DATA):



















    ALLDEBUG=False
    DEBUG=True

    #测试框架
    URLss={
        # "/":APP_index.admin.admin_return,
        # "/admin":APP_index.admin.admin_return2,
        # "/admin2":APP_index.admin.admin_return3,
        # "/setcookie":APP_index.admin.setcookie,
        # "/CESsetcookie":APP_index.admin.setcookie_of_new,
        # "/delcookie":APP_index.admin.cookie_del,
    }





















    # try:
    #     X=DATA["ARELUSS_TO_FILE_IS"]
    #     if ALLDEBUG==True:print("跨度密匙存在 跳过:"+urlindex.__name__)
    #     return DATA
    # except Exception:
    #     if ALLDEBUG==True:print("跨度密匙不存在 执行:",urlindex.__name__)

            

    for i in URLss:
        OA=DATA["url"]
        PAAA=OA.replace(".html","")
        if PAAA==i:
            if DEBUG==True:print(f"{DATA['Host']}:{DATA['request']}->{URLss[i].__name__}")
            STATUS=URLss[i](DATA)
    
            return STATUS
        else:
            pass
    if DEBUG==True:print(f"{DATA['Host']}:{DATA['request']}->APP_index.admin.the404")
    return APP_index.admin.the404(DATA)
    