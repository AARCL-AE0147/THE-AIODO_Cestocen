print('''------------------------------------------------
        ADESK93 CONSOLE
        loading..........OK
        Developers:AARCL

        THE ADESK93 - 0.02
------------------------------------------------- ''')

class UTF():
    def ENCODE(FUNC):
        def inner():
            BDS=FUNC()
            return BDS.encode()
        return inner

    def DECODE(FUNC):
        def inner():
            BDS=FUNC()
            return BDS.decode()
        return inner































































































class AWKFaction():
    def txt_load(PATH):
        debug=None
        f=open(PATH,"rb")
        AS=f.read().decode()
        if debug==True:print(AS)
        return AS



