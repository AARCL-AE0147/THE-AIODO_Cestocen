import shutil

import os

import sys



APP=sys.argv

print(APP)

try:
    if APP[1]==True:pass
except Exception:
    print("If you dont know how to do this, use /manage.py help")

if APP[1]=="appstart":
    
    def appstart(path):
        print(path)
        shutil.copyfile("WEB_DATA/RE.py",path)
    appstart(APP[2])

if APP[1]=="runserver":
    try:
        if APP[2]==None:
            the="start.py"
        else:
            the="start.py "+APP[2]
    except Exception:
        the="start.py"

    def runserver(port):
        os.system(port)

    
    runserver(the)

if APP[1]=="help":
    print("""

        runserver [port] -运行服务

        appstart [path] -创建APP

        installmod -下载必要组件

        time -查看服务器接收到返回所需要的平均时间

    """)

if APP[1]=="installmod":
    import AIODO93
    AIODO93.AIODO93_mod.AWKFaction_mod()
    print()
    print()
    print("If you still get an error after installmod, you need to start a VPN")
    print("如果你installmod后使用依然报错 代表你需要启动一个VPN再次执行installmod")

if APP[1]=="time":
    f=open("./WEB_DATA/accept_time.txt","r")
    PP=f.read()

    AA=PP.split("\n",99999999)

    O=0.0
    AA.pop(-1)
    for i in AA:
        O=O+float(i)

    print(O/len(AA),O)
