import AIODO93

retuper=AIODO93.AWKFaction.return_request
HTML_load=AIODO93.AWKFaction.HTML
data_encode=AIODO93.AWKFaction.return_encode


def REto(request):
    p=HTML_load("./HTML/CES2.html")
    retuper.return200(p)